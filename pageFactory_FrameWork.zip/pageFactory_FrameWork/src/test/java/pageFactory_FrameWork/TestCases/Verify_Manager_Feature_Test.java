package pageFactory_FrameWork.TestCases;

import org.testng.annotations.Test;

import Base.Page;
import pageFactory_FrameWork.Locators.ManagerFeature;


public class Verify_Manager_Feature_Test{
	@Test
	public void managerLoginButton() {
		
		Page p=new Page();
		p.initConfiguration();
		
		ManagerFeature home =new ManagerFeature();
		home.Manager();
	    //page.Browserquit();
	}

}
