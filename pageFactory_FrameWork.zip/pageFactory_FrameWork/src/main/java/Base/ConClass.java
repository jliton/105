package Base;

public class ConClass {
	public static String Browser="chrome";
	public static String Url="http://www.way2automation.com/angularjs-protractor/banking/#/login";
	public static long implicitWait=10;
	
}


