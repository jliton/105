package Base;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import UtilityFiles.ExcelReader;
import UtilityFiles.ReportManager;
//baseclass
public class Page {
	public static WebDriver driver;
//	protected Properties config = new Properties();
//	public static Properties OR = new Properties();
//	FileInputStream fis;
	public static WebDriverWait wait;
	public ExtentReports repo = ReportManager.GetIns();
	public static ExtentTest test;

	public static Logger log = Logger.getLogger("DevInfo");
	public static ExcelReader excel = new ExcelReader(
			System.getProperty("user.dir") + "\\src\\test\\Excel\\TestData.xlsx");

	public void initConfiguration() {
		if (ConClass.Browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\src\\test\\Executeable\\chromedriver.exe");
			driver = new ChromeDriver();
			log.debug("Chrome is Launching");
			driver.get(ConClass.Url);
			driver.manage().window().maximize();
			wait = new WebDriverWait(driver, 5);

		}

	}

	public void Browserquit() {

		if (driver != null) {

			driver.quit();
			log.debug("test execution completed");

		}
	}
}
