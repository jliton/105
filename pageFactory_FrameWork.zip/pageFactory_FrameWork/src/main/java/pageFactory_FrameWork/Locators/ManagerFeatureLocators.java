package pageFactory_FrameWork.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ManagerFeatureLocators {
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Bank Manager Login')]")
	
	public WebElement ManagerLoginButton;

	

}
