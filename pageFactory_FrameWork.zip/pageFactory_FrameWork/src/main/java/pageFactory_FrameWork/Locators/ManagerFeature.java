package pageFactory_FrameWork.Locators;

import org.openqa.selenium.support.PageFactory;

import Base.Page;

public class ManagerFeature extends Page {

	public ManagerFeatureLocators ML;
	
	public ManagerFeature() {
	
		this.ML= new ManagerFeatureLocators();
		PageFactory.initElements(driver, this.ML);

	}

	public void Manager() {

		ML.ManagerLoginButton.click();
		
	}
}
