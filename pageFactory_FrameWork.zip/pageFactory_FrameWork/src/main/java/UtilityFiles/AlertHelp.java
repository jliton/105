package UtilityFiles;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import Base.Page;



public class AlertHelp extends Page {
	
	@Test(dataProviderClass=TestUtill.class,dataProvider = "dp")
	public static void ForAlert(String alertTextDisplayed) {
	
	Alert alert = wait.until(ExpectedConditions.alertIsPresent());
	Assert.assertTrue(alert.getText().contains(alertTextDisplayed));

	alert.accept();

}
}